<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 4:02 PM
 */
?>


<?php $__env->startSection('title'); ?>
    Home | IQAC-SUST
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="main-slideshow">
                    <div class="flexslider">
                        <ul class="slides">
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <img src="<?php echo e(asset( $slider->slider_photo )); ?>" alt="<?php echo e($slider->photo_title); ?>" />
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul> <!-- /.slides -->
                    </div> <!-- /.flexslider -->
                </div> <!-- /.main-slideshow -->
            </div> <!-- /.col-md-12 -->
        </div>
    </div>

    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget-item">
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2 class="welcome-text"><?php echo e($content->home_title); ?></h2>
                            <p style="text-align: justify">
                                <?php echo $content->home_description; ?>

                            </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /.widget-item -->
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->

                <div class="row">

                    <!-- Show Recent Activities -->
                    <div class="col-md-6">
                        <div class="widget-main">
                            <div class="widget-main-title">
                                <h4 class="widget-title">Recent Activities</h4>
                            </div> <!-- /.widget-main-title -->
                            <div class="widget-inner">
                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="blog-list-post clearfix">
                                    <div class="blog-list-thumb">
                                        <a href="#"><img src="<?php echo e(asset($activity->image)); ?>" alt="<?php echo e($activity->activity_title); ?>"></a>
                                    </div>
                                    <div class="blog-list-details">
                                        <h5 class="blog-list-title"><a href="#"><?php echo e($activity->activity_title); ?></a></h5>
                                        <p class="blog-list-meta small-text"><span><a href="#"><?php echo e(date('d F, Y', strtotime( $activity->activity_date ))); ?></a></span></p>
                                    </div>
                                </div> <!-- /.recent-activities-post -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div> <!-- /.widget-inner -->
                        </div> <!-- /.widget-main -->
                    </div> <!-- /col-md-6 -->

                    <!-- Show Latest Events List -->
                    <div class="col-md-6">
                        <div class="widget-main">
                            <div class="widget-main-title">
                                <h4 class="widget-title">Upcoming Events</h4>
                            </div> <!-- /.widget-main-title -->
                            <div class="widget-inner">
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="event-small-list clearfix">
                                    <div class="calendar-small">
                                        <span class="s-month"><?php echo e(date('M', strtotime( $event->event_date ))); ?></span>
                                        <span class="s-date"><?php echo e(date('d', strtotime( $event->event_date ))); ?></span>
                                    </div>
                                    <div class="event-small-details">
                                        <h5 class="event-small-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                        <p class="event-small-meta small-text"><?php echo e($event->event_place.', Time '.date('H:i A', strtotime( $event->event_time ))); ?></p>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div> <!-- /.widget-inner -->
                        </div> <!-- /.widget-main -->
                    </div> <!-- /.col-md-6 -->
                </div> <!-- /.row -->
            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Notice Board</h4>
                    </div>
                    <div class="widget-inner" style="height:300px;">
                        <marquee behavior="scroll" direction="up" scrollamount="5" onmouseover="this.stop();" onmouseout="this.start();" style="height: 260px;">
                            <ul>
                                <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <p><?php echo e($notice->notice_title); ?> <a href="<?php echo e(url('notice/'.$notice->id)); ?>" class="btn btn-success btn-xs">Details...</a></p>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </marquee>
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset($gallery->uploaded_image)); ?>" title="<?php echo e($gallery->image_title); ?>">
                                    <img src="<?php echo e(asset($gallery->uploaded_image)); ?>" alt="<?php echo e($gallery->image_title); ?>" />
                                </a>
                            </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>