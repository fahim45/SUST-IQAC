<?php $__env->startSection('title'); ?>
    Manage Events
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In Manage Events</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-success">
                    <h2 class="text-center text-success"><?php echo e($message); ?></h2>
                </div>
            <?php endif; ?>
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>SL</th>
                        <th>Dept. Name</th>
                        <th>Event Title</th>
                        <th>Event Place</th>
                        <th>Event Date</th>
                        <th>Event Time</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($event->department_name); ?></td>
                        <td><?php echo e($event->event_title); ?></td>
                        <td><?php echo e($event->event_place); ?></td>
                        <td><?php echo e(date('F d, Y', strtotime( $event->event_date ))); ?></td>
                        <td><?php echo e(date('H:i A', strtotime( $event->event_time ))); ?></td>
                        <td><?php echo e($event->publication_status ==1 ? 'Published':'Unpublished'); ?></td>
                        <td>
                            <a href="<?php echo e(url('/events/view-events/'.$event->id)); ?>" class="btn btn-info btn-xs" title="View"><span class="glyphicon glyphicon-zoom-in"></span></a>
                            <?php if($event->publication_status == 1): ?>
                                <a href="<?php echo e(url('/events/unpublished-events/'.$event->id)); ?>" class="btn btn-success btn-xs" title="Published"><span class="glyphicon glyphicon-arrow-up"></span></a>
                            <?php else: ?>
                                <a href="<?php echo e(url('/events/published-events/'.$event->id)); ?>" class="btn btn-warning btn-xs" title="Unpublished"><span class="glyphicon glyphicon-arrow-down"></span></a>
                            <?php endif; ?>
                            <a href="<?php echo e(url('/events/edit-events/'.$event->id)); ?>" class="btn btn-primary btn-xs" title="Edit"><span class="glyphicon glyphicon-edit"></span></a>
                            <a href="<?php echo e(url('/events/delete-events/'.$event->id)); ?>" class="btn btn-danger btn-xs" title="Delete" onclick="return confirm('Are You Sure To Delete This?');"><span class="glyphicon glyphicon-trash"></span></a>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>