<?php $__env->startSection('title'); ?>
    View Notice
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In View Notice</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($notice->id); ?></td>
                    </tr>
                    <tr>
                        <th>Notice Title</th>
                        <td><?php echo e($notice->notice_title); ?></td>
                    </tr>
                    <tr>
                        <th>Publication Date</th>
                        <td><?php echo e(date('d F, Y', strtotime( $notice->created_at ))); ?></td>
                    </tr>
                    <tr>
                        <th>Notice Details</th>
                        <td><?php echo $notice->notice_description; ?></td>
                    </tr>
                    <tr>
                        <th>Publication Status</th>
                        <td><?php echo e($notice->publication_status ==1 ? 'Published':'Unpublished'); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>