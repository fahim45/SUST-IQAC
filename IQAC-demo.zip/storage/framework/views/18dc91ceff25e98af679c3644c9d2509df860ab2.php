<?php
/**
 * Created by PhpStorm.
 * User: fahim_foysal_kamal
 * Date: 08-Jan-18
 * Time: 6:07 PM
 */
?>


<?php $__env->startSection('title'); ?>
    Manage Home Content
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In Manage Home Content</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-success">
                    <h2 class="text-center text-success"><?php echo e($message); ?></h2>
                </div>
            <?php endif; ?>
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>SL</th>
                        <th>Home Title</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $homeContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homeContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($homeContent->home_title); ?></td>
                            <td><?php echo e($homeContent->publication_status ==1 ? 'Published':'Unpublished'); ?></td>
                            <td>
                                <a href="<?php echo e(url('/home/content/view-content/'.$homeContent->id)); ?>" class="btn btn-info btn-xs" title="View"><span class="glyphicon glyphicon-zoom-in"></span></a>
                                <?php if($homeContent->publication_status == 1): ?>
                                    <a href="<?php echo e(url('/home/content/unpublished-content/'.$homeContent->id)); ?>" class="btn btn-success btn-xs" title="Published"><span class="glyphicon glyphicon-arrow-up"></span></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/home/content/published-content/'.$homeContent->id)); ?>" class="btn btn-warning btn-xs" title="Unpublished"><span class="glyphicon glyphicon-arrow-down"></span></a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('/home/content/edit-content/'.$homeContent->id)); ?>" class="btn btn-primary btn-xs" title="Edit"><span class="glyphicon glyphicon-edit"></span></a>
                                <a href="<?php echo e(url('/home/content/delete-content/'.$homeContent->id)); ?>" class="btn btn-danger btn-xs" title="Delete" onclick="return confirm('Are You Sure To Delete This?');"><span class="glyphicon glyphicon-trash"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>