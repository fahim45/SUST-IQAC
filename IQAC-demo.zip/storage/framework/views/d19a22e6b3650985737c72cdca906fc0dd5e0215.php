<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 10:48 PM
 */
?>



<?php $__env->startSection('title'); ?>
IQAC Event List | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-event-item">
                            <div class="box-content-inner clearfix">
                                <div class="list-event-header">
                                    <span class="event-place small-text"><i class="fa fa-asterisk"></i><?php echo e($event->department_name); ?></span>
                                    <span class="event-date small-text"><i class="fa fa-calendar-o"></i><?php echo e(date('d M, Y', strtotime( $event->event_date))); ?></span>
                                    <span class="event-place small-text">&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-home"></i><?php echo e($event->event_place); ?></span>
                                    
                                </div>
                                <h5 class="event-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                <p><?php echo $event->event_description; ?></p>
                            </div> <!-- /.box-content-inner -->
                        </div> <!-- /.list-event-item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->

                
                    
                        
                            
                            
                        
                    
                

            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Recent Activities</h4>
                    </div> <!-- /.widget-main-title -->
                    <div class="widget-inner">
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="blog-list-post clearfix">
                                <div class="blog-list-thumb">
                                    <a href="#"><img src="<?php echo e(asset($activity->image)); ?>" alt="<?php echo e($activity->activity_title); ?>"></a>
                                </div>
                                <div class="blog-list-details">
                                    <h5 class="blog-list-title"><a href="#"><?php echo e($activity->activity_title); ?></a></h5>
                                    <p class="blog-list-meta small-text"><span><a href="#"><?php echo e(date('d F, Y', strtotime( $activity->activity_date ))); ?></a></span></p>
                                </div>
                            </div> <!-- /.recent-activities-post -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="thumb-small-gallery">
                                    <a class="fancybox" rel="gallery1" href="<?php echo e(asset($gallery->uploaded_image)); ?>" title="<?php echo e($gallery->image_title); ?>">
                                        <img src="<?php echo e(asset($gallery->uploaded_image)); ?>" alt="<?php echo e($gallery->image_title); ?>" />
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div> <!-- /.col-md-4 -->

        </div> <!-- /.row -->
    </div> <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>