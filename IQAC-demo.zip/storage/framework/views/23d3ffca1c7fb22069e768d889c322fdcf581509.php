<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 4:02 PM
 */
?>


<?php $__env->startSection('title'); ?>
    List of SAC Members | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Members of SAC</h4>
                    </div>
                    <div class="qac-members" style="margin-top: 10px;">
                        <div class="col-md-12">
                            <div class="panel-group" id="accordion">
                                <div class="panel panel-default">
                                    <div class="panel-heading" style="background-color: #4782B2;">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                                <h3><b>1<sup>st</sup> Phase</b></h3>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse">
                                        <div class="panel-body table-responsive">
                                            <table class="table table-bordered table-striped">
                                                <tr>
                                                    <th>Department</th>
                                                    <th>Name</th>
                                                    <th>Role</th>
                                                    <th>Mobile No</th>
                                                    <th>Email</th>
                                                </tr>
                                                <?php $__currentLoopData = $sacOneMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sacOneMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td rowspan="3"><?php echo e($sacOneMember->department_name); ?></td>
                                                    <td><?php echo e($sacOneMember->sac_one_name); ?></td>
                                                    <td><?php echo e($sacOneMember->sac_one_role==1?'Head':'Member'); ?></td>
                                                    <td><a href="tel:+88<?php echo e($sacOneMember->sac_one_mobile); ?>"><?php echo e($sacOneMember->sac_one_mobile); ?></a></td>
                                                    <td><a href="mailto:<?php echo e($sacOneMember->sac_one_email); ?>"><?php echo e($sacOneMember->sac_one_email); ?></a></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e($sacOneMember->sac_two_name); ?></td>
                                                    <td><?php echo e($sacOneMember->sac_two_role==1?'Head':'Member'); ?></td>
                                                    <td><a href="tel:+88<?php echo e($sacOneMember->sac_two_mobile); ?>"><?php echo e($sacOneMember->sac_two_mobile); ?></a></td>
                                                    <td><a href="mailto:<?php echo e($sacOneMember->sac_two_email); ?>"><?php echo e($sacOneMember->sac_two_email); ?></a></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e($sacOneMember->sac_three_name); ?></td>
                                                    <td><?php echo e($sacOneMember->sac_three_role==1?'Head':'Member'); ?></td>
                                                    <td><a href="tel:+88<?php echo e($sacOneMember->sac_three_mobile); ?>"><?php echo e($sacOneMember->sac_three_mobile); ?></a></td>
                                                    <td><a href="mailto:<?php echo e($sacOneMember->sac_three_email); ?>"><?php echo e($sacOneMember->sac_three_email); ?></a></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" style="background-color: #4782B2;">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                                <h3><b>2<sup>nd</sup> Phase</b></h3>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse">
                                        <div class="panel-body table-responsive">
                                            <table class="table table-bordered table-striped">
                                                <tr>
                                                    <th>Department</th>
                                                    <th>Name</th>
                                                    <th>Role</th>
                                                    <th>Mobile No</th>
                                                    <th>Email</th>
                                                </tr>
                                                <?php $__currentLoopData = $sacTwoMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sacTwoMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td rowspan="3"><?php echo e($sacTwoMember->department_name); ?></td>
                                                        <td><?php echo e($sacTwoMember->sac_one_name); ?></td>
                                                        <td><?php echo e($sacTwoMember->sac_one_role==1?'Head':'Member'); ?></td>
                                                        <td><a href="tel:+88<?php echo e($sacTwoMember->sac_one_mobile); ?>"><?php echo e($sacTwoMember->sac_one_mobile); ?></a></td>
                                                        <td><a href="mailto:<?php echo e($sacTwoMember->sac_one_email); ?>"><?php echo e($sacTwoMember->sac_one_email); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo e($sacTwoMember->sac_two_name); ?></td>
                                                        <td><?php echo e($sacTwoMember->sac_two_role==1?'Head':'Member'); ?></td>
                                                        <td><a href="tel:+88<?php echo e($sacTwoMember->sac_two_mobile); ?>"><?php echo e($sacTwoMember->sac_two_mobile); ?></a></td>
                                                        <td><a href="mailto:<?php echo e($sacTwoMember->sac_two_email); ?>"><?php echo e($sacTwoMember->sac_two_email); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo e($sacTwoMember->sac_three_name); ?></td>
                                                        <td><?php echo e($sacTwoMember->sac_three_role==1?'Head':'Member'); ?></td>
                                                        <td><a href="tel:+88<?php echo e($sacTwoMember->sac_three_mobile); ?>"><?php echo e($sacTwoMember->sac_three_mobile); ?></a></td>
                                                        <td><a href="mailto:<?php echo e($sacTwoMember->sac_three_email); ?>"><?php echo e($sacTwoMember->sac_three_email); ?></a></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" style="background-color: #4782B2;">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                                                <h3><b>3<sup>rd</sup> Phase</b></h3>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse">
                                        <div class="panel-body table-responsive">
                                            <table class="table table-bordered table-striped">
                                                <tr>
                                                    <th>Department</th>
                                                    <th>Name</th>
                                                    <th>Role</th>
                                                    <th>Mobile No</th>
                                                    <th>Email</th>
                                                </tr>
                                                <?php $__currentLoopData = $sacThreeMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sacThreeMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td rowspan="3"><?php echo e($sacThreeMember->department_name); ?></td>
                                                        <td><?php echo e($sacThreeMember->sac_one_name); ?></td>
                                                        <td><?php echo e($sacThreeMember->sac_one_role==1?'Head':'Member'); ?></td>
                                                        <td><a href="tel:+88<?php echo e($sacThreeMember->sac_one_mobile); ?>"><?php echo e($sacThreeMember->sac_one_mobile); ?></a></td>
                                                        <td><a href="mailto:<?php echo e($sacThreeMember->sac_one_email); ?>"><?php echo e($sacThreeMember->sac_one_email); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo e($sacThreeMember->sac_two_name); ?></td>
                                                        <td><?php echo e($sacThreeMember->sac_two_role==1?'Head':'Member'); ?></td>
                                                        <td><a href="tel:+88<?php echo e($sacThreeMember->sac_two_mobile); ?>"><?php echo e($sacThreeMember->sac_two_mobile); ?></a></td>
                                                        <td><a href="mailto:<?php echo e($sacThreeMember->sac_two_email); ?>"><?php echo e($sacThreeMember->sac_two_email); ?></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td><?php echo e($sacThreeMember->sac_three_name); ?></td>
                                                        <td><?php echo e($sacThreeMember->sac_three_role==1?'Head':'Member'); ?></td>
                                                        <td><a href="tel:+88<?php echo e($sacThreeMember->sac_three_mobile); ?>"><?php echo e($sacThreeMember->sac_three_mobile); ?></a></td>
                                                        <td><a href="mailto:<?php echo e($sacThreeMember->sac_three_email); ?>"><?php echo e($sacThreeMember->sac_three_email); ?></a></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- /.col-md-12 -->
                    </div>
                </div>
            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Upcoming Events</h4>
                    </div>
                    <div class="widget-inner">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="event-small-list clearfix">
                                <div class="calendar-small">
                                    <span class="s-month"><?php echo e(date('M', strtotime( $event->event_date ))); ?></span>
                                    <span class="s-date"><?php echo e(date('d', strtotime( $event->event_date ))); ?></span>
                                </div>
                                <div class="event-small-details">
                                    <h5 class="event-small-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                    <p class="event-small-meta small-text"><?php echo e($event->event_place.', Time '.date('H:i A', strtotime( $event->event_time ))); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- /.widget-inner -->
                </div><!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="thumb-small-gallery">
                                    <a class="fancybox" rel="gallery1" href="<?php echo e(asset($gallery->uploaded_image)); ?>" title="<?php echo e($gallery->image_title); ?>">
                                        <img src="<?php echo e(asset($gallery->uploaded_image)); ?>" alt="<?php echo e($gallery->image_title); ?>" />
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>