<?php
/**
 * Created by PhpStorm.
 * User: IQAC_SUST
 * Date: 09-Jan-18
 * Time: 11:49 AM
 */
?>



<?php $__env->startSection('title'); ?>
    Manage Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In Manage Slider</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-success">
                    <h2 class="text-center text-success"><?php echo e($message); ?></h2>
                </div>
            <?php endif; ?>
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>SL</th>
                        <th>Slider Title</th>
                        <th>Slider Image</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($slider->photo_title); ?></td>
                            <td><img src="<?php echo e(asset($slider->slider_photo)); ?>" alt="<?php echo e($slider->photo_title); ?>" style="width: 180px;"></td>
                            <td><?php echo e($slider->publication_status ==1 ? 'Published':'Unpublished'); ?></td>
                            <td>
                                <a href="<?php echo e(asset($slider->slider_photo)); ?>" class="btn btn-info btn-xs" target="_blank" title="View"><span class="glyphicon glyphicon-zoom-in"></span></a>
                                <?php if($slider->publication_status == 1): ?>
                                    <a href="<?php echo e(url('/home/slider/unpublished-slider/'.$slider->id)); ?>" class="btn btn-success btn-xs" title="Published"><span class="glyphicon glyphicon-arrow-up"></span></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/home/slider/published-slider/'.$slider->id)); ?>" class="btn btn-warning btn-xs" title="Unpublished"><span class="glyphicon glyphicon-arrow-down"></span></a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('/home/slider/edit-slider/'.$slider->id)); ?>" class="btn btn-primary btn-xs" title="Edit"><span class="glyphicon glyphicon-edit"></span></a>
                                <a href="<?php echo e(url('/home/slider/delete-slider/'.$slider->id)); ?>" class="btn btn-danger btn-xs" title="Delete" onclick="return confirm('Are You Sure To Delete This?');"><span class="glyphicon glyphicon-trash"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>