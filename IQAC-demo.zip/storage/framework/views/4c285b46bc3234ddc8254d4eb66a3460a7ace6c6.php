<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 10:48 PM
 */
?>



<?php $__env->startSection('title'); ?>
    Recent Activities | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="list-event-item">
                            <div class="box-content-inner clearfix">
                                <h1 class="text-center text-danger" style="font-weight: 400;">Site Is Under Construction</h1>
                                
                                
                                
                            </div> <!-- /.box-content-inner -->
                        </div> <!-- /.list-event-item -->
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->

                
                
                
                
                
                
                
                

            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Upcoming Events</h4>
                    </div> <!-- /.widget-main-title -->
                    <div class="widget-inner">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="event-small-list clearfix">
                                <div class="calendar-small">
                                    <span class="s-month"><?php echo e(date('M', strtotime( $event->event_date ))); ?></span>
                                    <span class="s-date"><?php echo e(date('d', strtotime( $event->event_date ))); ?></span>
                                </div>
                                <div class="event-small-details">
                                    <h5 class="event-small-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                    <p class="event-small-meta small-text"><?php echo e($event->event_place.', Time '.date('H:i A', strtotime( $event->event_time ))); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery1.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery1.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery2.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery2.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery3.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery3.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery4.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery4.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery5.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery5.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery6.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery6.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery7.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery7.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery8.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery8.jpg" alt=""/>
                                </a>
                            </div>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div> <!-- /.col-md-4 -->

        </div> <!-- /.row -->
    </div> <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>