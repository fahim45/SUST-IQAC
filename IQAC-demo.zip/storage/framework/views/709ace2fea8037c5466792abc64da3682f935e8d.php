<?php $__env->startSection('title'); ?>
    Manage Activities
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In Manage Activities</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-success">
                    <h2 class="text-center text-success"><?php echo e($message); ?></h2>
                </div>
            <?php endif; ?>
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>SL</th>
                        <th>Dept. Name</th>
                        <th>Activity Title</th>
                        <th>Activity Place</th>
                        <th>Activity Date</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($activity->department_name); ?></td>
                        <td><?php echo e($activity->activity_title); ?></td>
                        <td><?php echo e($activity->activity_place); ?></td>
                        <td><?php echo e(date('F d, Y', strtotime( $activity->activity_date ))); ?></td>
                        <td><?php echo e($activity->publication_status ==1 ? 'Published':'Unpublished'); ?></td>
                        <td>
                            <a href="<?php echo e(url('/activities/view-activities/'.$activity->id)); ?>" class="btn btn-info btn-xs" title="View"><span class="glyphicon glyphicon-zoom-in"></span></a>
                            <?php if($activity->publication_status == 1): ?>
                                <a href="<?php echo e(url('/activities/unpublished-activities/'.$activity->id)); ?>" class="btn btn-success btn-xs" title="Published"><span class="glyphicon glyphicon-arrow-up"></span></a>
                            <?php else: ?>
                                <a href="<?php echo e(url('/activities/published-activities/'.$activity->id)); ?>" class="btn btn-warning btn-xs" title="Unpublished"><span class="glyphicon glyphicon-arrow-down"></span></a>
                            <?php endif; ?>
                            <a href="<?php echo e(url('/activities/edit-activities/'.$activity->id)); ?>" class="btn btn-primary btn-xs" title="Edit"><span class="glyphicon glyphicon-edit"></span></a>
                            <a href="<?php echo e(url('/activities/delete-activities/'.$activity->id)); ?>" class="btn btn-danger btn-xs" title="Delete" onclick="return confirm('Are You Sure To Delete This?');"><span class="glyphicon glyphicon-trash"></span></a>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>