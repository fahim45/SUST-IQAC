<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 10:48 PM
 */
?>



<?php $__env->startSection('title'); ?>
    Office Staff | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .navy-bg {
            background-color: #F3F3F3;
            color: #ffffff;
        }
        .m-b-md {
            height: 75px;
            margin-bottom: 20px;
        }
        img.circle-border {
            width: 100%;
            overflow: hidden;
        }
        img {
            -webkit-transition: all 0.5s ease;
        }
        img:hover {
            transform: scale(1.1);
        }
    </style>
    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-12">
                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Office Staffs</h4>
                    </div>
                    <div class="office-staff" style="margin-top: 10px;">
                        <?php $__currentLoopData = $officeStaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officeStaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="widget-head-color-box navy-bg p-lg text-center">
                                <div class="m-b-md">
                                    <h2 class="font-bold no-margins">
                                        <?php echo e($officeStaff->name); ?>

                                    </h2>
                                    <h4><b><?php echo e($officeStaff->designation); ?></b></h4>
                                </div>
                                <img src="<?php echo e(asset( $officeStaff->picture )); ?>" class="img-circle circle-border m-b-md" alt="profile" style="height: 290px;">
                            </div>
                            <div class="widget-text-box">
                                <address class="m-t-md">
                                    <strong><?php echo e($officeStaff->office_address); ?></strong><br>
                                    <b>Call:</b> <?php echo e($officeStaff->mobile_no); ?><br>
                                    <b>Email:</b> <a href="mailto:<?php echo e($officeStaff->email); ?>"><?php echo e($officeStaff->email); ?></a><br>
                                </address>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div> <!-- /.col-md-8 -->
            
            <!---->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>