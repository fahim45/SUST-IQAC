<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 10:48 PM
 */
?>



<?php $__env->startSection('title'); ?>
    Executive Staffs | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Executive Staffs</h4>
                    </div>
                    <div class="qac-members" style="margin-top: 10px;">
                        <?php $__currentLoopData = $executiveStaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $executiveStaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <div class="widget-head-color-box navy-bg p-lg text-center">
                                <div class="m-b-md">
                                    <h2 class="font-bold no-margins" style="font-size: 20px;">
                                        <b><?php echo e($executiveStaff->name); ?></b>
                                    </h2>
                                    <h4><b><?php echo e($executiveStaff->designation); ?></b></h4>
                                </div>
                                <img src="<?php echo e(asset($executiveStaff->picture)); ?>" class="img-circle circle-border m-b-md" alt="<?php echo e($executiveStaff->name); ?>" style="height: 290px;">
                            </div>
                            <div class="widget-text-box">
                                <address class="m-t-md">
                                    <strong><?php echo e($executiveStaff->office_address); ?></strong><br>
                                    <b>Call:</b> <?php echo e($executiveStaff->mobile_no); ?><br>
                                    <b>Email:</b> <a href="mailto:<?php echo e($executiveStaff->email); ?>"><?php echo e($executiveStaff->email); ?></a><br>
                                </address>
                                <div>
                                    <span><a href="<?php echo e($executiveStaff->details_link); ?>" target="_blank" class="btn btn-default">About <?php echo e($executiveStaff->designation); ?></a></span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Upcoming Events</h4>
                    </div> <!-- /.widget-main-title -->
                    <div class="widget-inner">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="event-small-list clearfix">
                                <div class="calendar-small">
                                    <span class="s-month"><?php echo e(date('M', strtotime( $event->event_date ))); ?></span>
                                    <span class="s-date"><?php echo e(date('d', strtotime( $event->event_date ))); ?></span>
                                </div>
                                <div class="event-small-details">
                                    <h5 class="event-small-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                    <p class="event-small-meta small-text"><?php echo e($event->event_place.', Time '.date('H:i A', strtotime( $event->event_time ))); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="thumb-small-gallery">
                                    <a class="fancybox" rel="gallery1" href="<?php echo e(asset($gallery->uploaded_image)); ?>" title="<?php echo e($gallery->image_title); ?>">
                                        <img src="<?php echo e(asset($gallery->uploaded_image)); ?>" alt="<?php echo e($gallery->image_title); ?>" />
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div> <!-- /.col-md-4 -->

        </div> <!-- /.row -->
    </div> <!-- /.container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>