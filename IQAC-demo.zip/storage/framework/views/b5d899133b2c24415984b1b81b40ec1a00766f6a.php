<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 4:02 PM
 */
?>


<?php $__env->startSection('title'); ?>
    Our Mission | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .item-1,
        .item-2,
        .item-3 {
            color: #000000;
            position: relative;
            font-size: 1.5em;
            animation-duration: 10s;
        }

        .item-1 {
            animation-name: anim-1;
        }

        .item-2 {
            animation-name: anim-2;
        }

        .item-3 {
            animation-name: anim-3;
        }

        @keyframes  anim-1 {
            0%, 8.3% {
                right: -100%;
                opacity: 0;
            }
            8.3%, 25% {
                right: 0;
                opacity: 1;
            }
            33.33%, 100% {
                right: 0;
                opacity: 1;
            }
        }

        @keyframes  anim-2 {
            0%, 33.33% {
                right: -100%;
                opacity: 0;
            }
            41.63%, 58.29% {
                right: 0;
                opacity: 1;
            }
            66.66%, 100% {
                right: 0;
                opacity: 1;
            }
        }

        @keyframes  anim-3 {
            0%, 66.66% {
                right: -100%;
                opacity: 0;
            }
            74.96%, 91.62% {
                right: 0;
                opacity: 1;
            }
            100% {
                right: 0;
                opacity: 1;
            }
        }

        .box-content-inner{
            background: url("<?php echo e(asset('/front/')); ?>/images/Chetona71.jpg");
            /*opacity: .15;*/
        }
    </style>

    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="row">

                    <div class="col-md-12">
                        <div class="list-event-item">
                            <div class="box-content-inner clearfix">
                                <div class="list-event-header">
                                    <h3><i class="fa fa-globe"></i> <b>Our Mission</b></h3>
                                </div>
                                <ul>
                                    <li class="item-1">
                                        <p>Developing quality systems for conscious, reliable, transparent, consistent
                                            academic and administrative performance of SUST.</p>
                                    </li>
                                    <li class="item-2">
                                        <p>Benchmarking the practices and processes with the best universities in the
                                            world.</p>
                                    </li>
                                    <li class="item-3">
                                        <p>Institutional quality enhancement through internalization of quality culture and
                                            institutionalization of best practices.</p>
                                    </li>
                                </ul>
                            </div> <!-- /.box-content-inner -->
                        </div> <!-- /.list-event-item -->
                    </div> <!-- /.col-md-12 -->

                </div> <!-- /.row -->
            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Upcoming Events</h4>
                    </div>
                    <div class="widget-inner">

                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="event-small-list clearfix">
                                <div class="calendar-small">
                                    <span class="s-month"><?php echo e(date('M', strtotime( $event->event_date ))); ?></span>
                                    <span class="s-date"><?php echo e(date('d', strtotime( $event->event_date ))); ?></span>
                                </div>
                                <div class="event-small-details">
                                    <h5 class="event-small-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                    <p class="event-small-meta small-text"><?php echo e($event->event_place.', Time '.date('H:i A', strtotime( $event->event_time ))); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div> <!-- /.widget-inner -->
                </div><!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery1.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery1.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery2.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery2.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery3.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery3.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery4.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery4.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery5.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery5.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery6.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery6.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery7.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery7.jpg" alt=""/>
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="<?php echo e(asset('/front/')); ?>/images/gallery/gallery8.jpg"
                                   title="Gallery Tittle One">
                                    <img src="<?php echo e(asset('/front/')); ?>/images/gallery/gallery8.jpg" alt=""/>
                                </a>
                            </div>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>