<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 4:02 PM
 */
?>


<?php $__env->startSection('title'); ?>
    List of QAC Members | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        /* CONTACTS */
        .contact-box {
            background-color: #ffffff;
            border: 1px solid #e7eaec;
            padding: 20px;
            margin-bottom: 20px;
        }

        .contact-box > a {
            color: inherit;
        }

        .contact-box.center-version {
            border: 1px solid #e7eaec;
            padding: 0;
        }

        .contact-box.center-version > a {
            display: block;
            background-color: #ffffff;
            padding: 20px;
            text-align: center;
        }

        .contact-box.center-version > a img {
            width:70%;
            margin-bottom: 10px;
        }

        .contact-box.center-version address {
            margin-bottom: 0;
        }

        .contact-box .contact-box-footer {
            text-align: center;
            background-color: #ffffff;
            border-top: 1px solid #e7eaec;
            padding: 15px 20px;
        }

    </style>

    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Members of QAC</h4>
                    </div>
                    <div class="qac-members" style="margin-top: 10px;">
                        <?php $__currentLoopData = $qacMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qacMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <div class="contact-box center-version">
                                <a href="<?php echo e($qacMember->details_link); ?>" target="_blank">
                                    <img alt="image" class="img-circle" src="<?php echo e(asset($qacMember->picture)); ?>">
                                    <div class="qac-member" style="height: 10em;">
                                        <h3 class="m-b-xs" style="font-size: 20px;"><strong><?php echo e($qacMember->name); ?></strong></h3>
                                        <div class="font-bold"><?php echo e($qacMember->designation); ?></div>
                                        <address class="m-t-md">
                                            <strong><?php echo e($qacMember->office_address); ?></strong><br>
                                            <abbr title="Phone">Phone:</abbr> <?php echo e($qacMember->mobile_no); ?><br>
                                            <abbr title="Email">Email:</abbr> <?php echo e($qacMember->email); ?>

                                        </address>
                                    </div>
                                </a>
                                <div class="contact-box-footer" style="border-top: 0;">
                                    <div class="m-t-xs btn-group">
                                        <a href="tel:<?php echo e($qacMember->mobile_no); ?>" class="btn btn-xs btn-default"><i class="fa fa-phone"></i> Call </a>
                                        <a href="mailto:<?php echo e($qacMember->email); ?>" class="btn btn-xs btn-default"><i class="fa fa-envelope"></i> Email</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Upcoming Events</h4>
                    </div>
                    <div class="widget-inner">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="event-small-list clearfix">
                                <div class="calendar-small">
                                    <span class="s-month"><?php echo e(date('M', strtotime( $event->event_date ))); ?></span>
                                    <span class="s-date"><?php echo e(date('d', strtotime( $event->event_date ))); ?></span>
                                </div>
                                <div class="event-small-details">
                                    <h5 class="event-small-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                    <p class="event-small-meta small-text"><?php echo e($event->event_place.', Time '.date('H:i A', strtotime( $event->event_time ))); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- /.widget-inner -->
                </div><!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="thumb-small-gallery">
                                    <a class="fancybox" rel="gallery1" href="<?php echo e(asset($gallery->uploaded_image)); ?>" title="<?php echo e($gallery->image_title); ?>">
                                        <img src="<?php echo e(asset($gallery->uploaded_image)); ?>" alt="<?php echo e($gallery->image_title); ?>" />
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>