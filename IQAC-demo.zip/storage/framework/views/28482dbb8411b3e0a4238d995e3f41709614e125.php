<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 4:05 PM
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="IQAC-SUST">

    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800' rel='stylesheet' type='text/css'>

    <!-- CSS Bootstrap & Custom -->
    <link href="<?php echo e(asset('/front/')); ?>/bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="<?php echo e(asset('/front/')); ?>/css/font-awesome.min.css" rel="stylesheet" media="screen">
    <link href="<?php echo e(asset('/front/')); ?>/css/animate.css" rel="stylesheet" media="screen">
    <link href="<?php echo e(asset('/front/')); ?>/css/style.css" rel="stylesheet" media="screen">
    <link href="<?php echo e(asset('/front/')); ?>/css/customize.css" rel="stylesheet" media="screen">
    <!-- Favicons -->
    <link rel="shortcut icon" href="<?php echo e(asset('/front/')); ?>/images/ico/favicon.ico">

    <!-- JavaScripts -->
    <script src="<?php echo e(asset('/front/')); ?>/js/jquery-1.10.2.min.js"></script>
    <script src="<?php echo e(asset('/front/')); ?>/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo e(asset('/front/')); ?>/js/modernizr.js"></script>

</head>
<body>

<!-- This one in here is responsive menu for tablet and mobiles -->
<?php echo $__env->make('front.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>

<!-- begin The Footer -->
<?php echo $__env->make('front.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="<?php echo e(asset('/front/')); ?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/front/')); ?>/js/plugins.js"></script>
<script src="<?php echo e(asset('/front/')); ?>/js/custom.js"></script>

</body>

</html>
