<?php
/**
 * Created by PhpStorm.
 * User: IQAC_SUST
 * Date: 21-Dec-17
 * Time: 12:26 PM
 */
?>


<?php $__env->startSection('title'); ?>
    Manage QAC Members
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In Manage QAC Members</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-success">
                    <h2 class="text-center text-success"><?php echo e($message); ?></h2>
                </div>
            <?php endif; ?>
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>SL</th>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>Office Address</th>
                        <th>Mobile No</th>
                        <th>Email</th>
                        <th>Details Link</th>
                        <th>Profile Picture</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $qacMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qacMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($qacMember->name); ?></td>
                            <td><?php echo e($qacMember->designation); ?></td>
                            <td><?php echo e($qacMember->office_address); ?></td>
                            <td><?php echo e($qacMember->mobile_no); ?></td>
                            <td><?php echo e($qacMember->email); ?></td>
                            <td><?php echo e($qacMember->details_link); ?></td>
                            <td><img src="<?php echo e(asset($qacMember->picture)); ?>" alt="<?php echo e($qacMember->name); ?>" style="height: 80px;"></td>
                            <td><?php echo e($qacMember->publication_status ? 'Published':'Unpublished'); ?></td>
                            <td>
                                <?php if($qacMember->publication_status == 1): ?>
                                    <a href="<?php echo e(url('/committee/qac/unpublished-qac-member/'.$qacMember->id)); ?>" class="btn btn-success btn-xs" title="Published"><span class="glyphicon glyphicon-arrow-up"></span></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/committee/qac/published-qac-member/'.$qacMember->id)); ?>" class="btn btn-warning btn-xs" title="Unpublished"><span class="glyphicon glyphicon-arrow-down"></span></a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('/committee/qac/edit-qac-member/'.$qacMember->id)); ?>" class="btn btn-primary btn-xs" title="Edit"><span class="glyphicon glyphicon-edit"></span></a>
                                <a href="<?php echo e(url('/committee/qac/delete-qac-member/'.$qacMember->id)); ?>" class="btn btn-danger btn-xs" title="Delete" onclick="return confirm('Are You Sure To Delete This?');"><span class="glyphicon glyphicon-trash"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>