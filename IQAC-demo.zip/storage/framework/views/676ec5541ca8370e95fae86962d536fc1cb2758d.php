<?php
/**
 * Created by PhpStorm.
 * User: IQAC_SUST
 * Date: 10-Dec-17
 * Time: 6:19 PM
 */
?>


<?php $__env->startSection('title'); ?>
    Manage Office Staff
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In Manage Office Staff</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-success">
                    <h2 class="text-center text-success"><?php echo e($message); ?></h2>
                </div>
            <?php endif; ?>
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>SL</th>
                        <th>Name</th>
                        <th>Designation</th>
                        <th>Office Address</th>
                        <th>Mobile No</th>
                        <th>Email</th>
                        <th>Profile Picture</th>
                        <th>Publication Status</th>
                        <th>Action</th>
                    </tr>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $officeStaffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officeStaff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($officeStaff->name); ?></td>
                            <td><?php echo e($officeStaff->designation); ?></td>
                            <td><?php echo e($officeStaff->office_address); ?></td>
                            <td><?php echo e($officeStaff->mobile_no); ?></td>
                            <td><?php echo e($officeStaff->email); ?></td>
                            <td><img src="<?php echo e(asset($officeStaff->picture)); ?>" alt="<?php echo e($officeStaff->name); ?>" style="height: 80px;"></td>
                            <td><?php echo e($officeStaff->publication_status ? 'Published':'Unpublished'); ?></td>
                            <td>
                                <?php if($officeStaff->publication_status == 1): ?>
                                    <a href="<?php echo e(url('/staff/office/unpublished-office-staff/'.$officeStaff->id)); ?>" class="btn btn-success btn-xs" title="Published"><span class="glyphicon glyphicon-arrow-up"></span></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/staff/office/published-office-staff/'.$officeStaff->id)); ?>" class="btn btn-warning btn-xs" title="Unpublished"><span class="glyphicon glyphicon-arrow-down"></span></a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('/staff/office/edit-office-staff/'.$officeStaff->id)); ?>" class="btn btn-primary btn-xs" title="Edit"><span class="glyphicon glyphicon-edit"></span></a>
                                <a href="<?php echo e(url('/staff/office/delete-office-staff/'.$officeStaff->id)); ?>" class="btn btn-danger btn-xs" title="Delete" onclick="return confirm('Are You Sure To Delete This?');"><span class="glyphicon glyphicon-trash"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>