<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 10:48 PM
 */
?>



<?php $__env->startSection('title'); ?>
    Manual Download | IQAC-SUST
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Here begin Main Content -->
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget-item">
                            <h2 class="welcome-text">Download IQAC Manuals</h2>
                            <table class="table table-border table-striped">
                                <tr>
                                    <th>No</th>
                                    <th>File Name</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($file->file_name); ?></td>
                                    <td><?php echo e(date('M d, Y', strtotime( $file->created_at ))); ?></td>
                                    <td>
                                        <a href="<?php echo e(asset($file->uploaded_file)); ?>" target="_blank" class="btn btn-primary btn-xs">View / Download</a>
                                    </td>
                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div> <!-- /.widget-item -->
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->
            </div> <!-- /.col-md-8 -->

            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Upcoming Events</h4>
                    </div>
                    <div class="widget-inner">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="event-small-list clearfix">
                                <div class="calendar-small">
                                    <span class="s-month"><?php echo e(date('M', strtotime( $event->event_date ))); ?></span>
                                    <span class="s-date"><?php echo e(date('d', strtotime( $event->event_date ))); ?></span>
                                </div>
                                <div class="event-small-details">
                                    <h5 class="event-small-title"><a href="#"><?php echo e($event->event_title); ?></a></h5>
                                    <p class="event-small-meta small-text"><?php echo e($event->event_place.', Time '.date('H:i A', strtotime( $event->event_time ))); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- /.widget-inner -->
                </div><!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Our Gallery</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="thumb-small-gallery">
                                    <a class="fancybox" rel="gallery1" href="<?php echo e(asset($gallery->uploaded_image)); ?>" title="<?php echo e($gallery->image_title); ?>">
                                        <img src="<?php echo e(asset($gallery->uploaded_image)); ?>" alt="<?php echo e($gallery->image_title); ?>" />
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>