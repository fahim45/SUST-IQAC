<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 09-Jan-18
 * Time: 1:11 PM
 */
?>


<?php $__env->startSection('title'); ?>
    View Content
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">In View Content</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="well">
                <table class="table table-bordered table-responsive">
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($viewContent->id); ?></td>
                    </tr>
                    <tr>
                        <th>Home Title</th>
                        <td><?php echo e($viewContent->home_title); ?></td>
                    </tr>
                    <tr>
                        <th>Home Description</th>
                        <td><?php echo $viewContent->home_description; ?></td>
                    </tr>
                    <tr>
                        <th>Publication Status</th>
                        <td><?php echo e($viewContent->publication_status ==1 ? 'Published':'Unpublished'); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>