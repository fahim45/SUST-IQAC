<?php
/**
 * Created by PhpStorm.
 * User: fahim foysal kamal
 * Date: 21-Nov-17
 * Time: 4:01 PM
 */
?>
<div class="responsive-navigation visible-sm visible-xs">
    <a href="#" class="menu-toggle-btn">
        <i class="fa fa-bars"></i>
    </a>
    <div class="responsive_menu">
        <ul class="main_menu">
            <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="#">Committee</a>
                <ul class="sub-menu">
                    <li><a href="<?php echo e(url('/sac-members')); ?>">SAC Members</a></li>
                    <li><a href="<?php echo e(url('/qac-members')); ?>">QAC Members</a></li>
                </ul>
            </li>
            <li><a href="#">Events & Activities</a>
                <ul class="sub-menu">
                    <li><a href="<?php echo e(url('/iqac-events-list')); ?>">IQAC Events</a></li>
                    <li><a href="<?php echo e(url('/poe-events-list')); ?>">PoE Events</a></li>
                    <li><a href="<?php echo e(url('/recent-activities')); ?>">Recent Activities</a></li>
                </ul>
            </li>
            <li><a href="<?php echo e(url('/gallery')); ?>">Gallery</a></li>
            <li><a href="<?php echo e(url('#')); ?>">QA Process</a></li>
            <li><a href="#">Staffs</a>
                <ul class="sub-menu">
                    <li><a href="<?php echo e(url('/executive-staff')); ?>">Executive Staff</a></li>
                    <li><a href="<?php echo e(url('/office-staff')); ?>">Office Staff</a></li>
                </ul>
            </li>
            <li><a href="<?php echo e(url('#')); ?>">Newsletter</a></li>
            <li><a href="#">Downloads</a>
                <ul class="sub-menu">
                    <li><a href="<?php echo e(url('/manual')); ?>">Manual</a></li>
                    <li><a href="<?php echo e(url('/documents')); ?>">Documents</a></li>
                </ul>
            </li>
            <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
        </ul> <!-- /.main_menu -->
    </div> <!-- /.responsive_menu -->
</div> <!-- /responsive_navigation -->


<header class="site-header">
    <div class="container">
        <div class="row">
            <div class="col-md-4 header-left">
                <p><i class="fa fa-phone"></i> <a href="tel:+880-821-717850">+880-821-717850</a></p>
                <p><i class="fa fa-envelope"></i> <a href="mailto:iqac-off@sust.edu">iqac-off@sust.edu</a></p>
            </div> <!-- /.header-left -->

            <div class="col-md-4">
                <div class="logo">
                    <a href="<?php echo e(url('/')); ?>" title="IQAC-SUST" rel="home">
                        <img src="<?php echo e(asset('/front/')); ?>/images/iqac-logo.png" alt="">
                    </a>
                </div> <!-- /.logo -->
            </div> <!-- /.col-md-4 -->

            <div class="col-md-4 header-right">
                <ul class="small-links">
                    <li><a href="<?php echo e(url('/our-mission')); ?>">Mission</a></li>
                    <li><a href="<?php echo e(url('/our-vision')); ?>">Vision</a></li>
                    <li><a href="<?php echo e(url('/our-objectives')); ?>">Objectives</a></li>
                    <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                </ul>
                <div class="search-form">
                    <form name="search_form" method="get" action="#" class="search_form">
                        <input type="text" name="s" placeholder="Search the site..." title="Search the site..." class="field_search">
                    </form>
                </div>
                <ul class="social-icons pull-right">
                    <li><a href="#" data-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" data-toggle="tooltip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" data-toggle="tooltip" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                    <li><a href="#" data-toggle="tooltip" title="Google+"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#" data-toggle="tooltip" title="RSS"><i class="fa fa-rss"></i></a></li>
                </ul> <!-- /.social-icons -->
            </div> <!-- /.header-right -->
        </div>
    </div> <!-- /.container -->

    <div class="nav-bar-main" role="navigation">
        <div class="container">
            <nav class="main-navigation clearfix visible-md visible-lg" role="navigation">
                <ul class="main-menu sf-menu">
                    <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="#">Committee</a>
                        <ul class="sub-menu">
                            <li class="<?php echo e(request()->is('sac-members') ? 'active' : ''); ?>"><a href="<?php echo e(url('/sac-members')); ?>">SAC Members</a></li>
                            <li class="<?php echo e(request()->is('qac-members') ? 'active' : ''); ?>"><a href="<?php echo e(url('/qac-members')); ?>">QAC Members</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Events & Activities</a>
                        <ul class="sub-menu">
                            <li class="<?php echo e(request()->is('iqac-events-list') ? 'active' : ''); ?>"><a href="<?php echo e(url('/iqac-events-list')); ?>">IQAC Events</a></li>
                            <li class="<?php echo e(request()->is('poe-events-list') ? 'active' : ''); ?>"><a href="<?php echo e(url('/poe-events-list')); ?>">PoE Events</a></li>
                            <li class="<?php echo e(request()->is('recent-activities') ? 'active' : ''); ?>"><a href="<?php echo e(url('/recent-activities')); ?>">Recent Activities</a></li>
                        </ul>
                    </li>
                    <li class="<?php echo e(request()->is('gallery') ? 'active' : ''); ?>"><a href="<?php echo e(url('/gallery')); ?>">Gallery</a></li>
                    <li><a href="<?php echo e(url('#')); ?>">QA Process</a></li>
                    <li><a href="#">Staffs</a>
                        <ul class="sub-menu">
                            <li class="<?php echo e(request()->is('executive-staff') ? 'active' : ''); ?>"><a href="<?php echo e(url('/executive-staff')); ?>">Executive Staff</a></li>
                            <li class="<?php echo e(request()->is('office-staff') ? 'active' : ''); ?>"><a href="<?php echo e(url('/office-staff')); ?>">Office Staff</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('#')); ?>">Newsletter</a></li>
                    <li><a href="#">Downloads</a>
                        <ul class="sub-menu">
                            <li class="<?php echo e(request()->is('manual') ? 'active' : ''); ?>"><a href="<?php echo e(url('/manual')); ?>">Manual</a></li>
                            <li class="<?php echo e(request()->is('documents') ? 'active' : ''); ?>"><a href="<?php echo e(url('/documents')); ?>">Documents</a></li>
                        </ul>
                    </li>
                    <li class="<?php echo e(request()->is('contact') ? 'active' : ''); ?>"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                </ul> <!-- /.main-menu -->
            </nav> <!-- /.main-navigation -->
        </div> <!-- /.container -->
    </div> <!-- /.nav-bar-main -->
</header> <!-- /.site-header -->
