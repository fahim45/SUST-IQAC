<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QACMember extends Model
{
    //
}
